<?php
global $allmodules;
$GLOBALS['allmodules']['0cce60bc0238aa03804682c801584991']='0cce60bc0238aa03804682c801584991.xml';
$GLOBALS['allmodules']['1f35620fb42d452fa2bdc1dee1690f92']='1f35620fb42d452fa2bdc1dee1690f92.xml';
$GLOBALS['allmodules']['572606600345b1a4bb8c810bbae434cc']='572606600345b1a4bb8c810bbae434cc.xml';
$GLOBALS['allmodules']['72ffa6fabe3c236f9238a2b281bc0f93']='72ffa6fabe3c236f9238a2b281bc0f93.xml';
$GLOBALS['allmodules']['9e7ce30633a50fd14a82080cb5aca73e']='9e7ce30633a50fd14a82080cb5aca73e.xml';
$GLOBALS['allmodules']['acb8b88eb4a6d4bfc375c18534f9439e']='acb8b88eb4a6d4bfc375c18534f9439e.xml';
$GLOBALS['allmodules']['b437d85a7a7bc778c9c79b5ec36ab9aa']='b437d85a7a7bc778c9c79b5ec36ab9aa.xml';
$GLOBALS['allmodules']['d7facbd1cf9979ae352bb8fe175bc59f']='d7facbd1cf9979ae352bb8fe175bc59f.xml';
?>